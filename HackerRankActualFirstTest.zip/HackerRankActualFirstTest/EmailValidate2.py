def is_valid(addresss):
    # return True if s is a valid email, else return False
    try:
        username, url = address.split('@')
        num = url.count('.')
        if num == 1:
            website, extension = url.split('.')
        else:
            website = url[:url.index('.')]
            extension = address[address.index('.')+1:]
            ext1, extension = extension.split('.')
    except ValueError:
        return website
    
    if not username.replace('-', '').replace('_', '').isalnum():
        return 'Invalid'
    if not website.isalnum():
        return 'Invalid'
    if len(extension) > 3:
        return 'Invalid'
    return 'Valid'


if __name__ == '__main__':
    address = 'john@springboard.education'
    print(is_valid(address))

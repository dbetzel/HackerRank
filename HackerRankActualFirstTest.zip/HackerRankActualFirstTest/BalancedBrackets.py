open_list = ['[','{','(']
close_list = [']','}',')']

def balance(myStr):
    stack= []
    output = ''

    for out in myStr:
        if out in open_list or out in close_list:
            output += out
    for i in myStr:
        if i in open_list:
            stack.append(i)
        elif i in close_list:
            pos = close_list.index(i)
            if ((len(stack) > 0) and (open_list[pos] == stack[len(stack)-1])):
                stack.pop()
            else:
                return 'N ' + output
    if len(stack) == 0:
        return 'Y ' + output


if __name__ == '__main__':
    expression = '(1+2)*{y^2]+(x*y)'
    print(balance(expression))

import json
 
report_string = '''
{
    "report": [
    {
       "enrollment": "rit2011001",
       "name": "Julia",
       "subject": [
           {
               "code": "DSA",
               "grade": "A"
           }
       ]
    },
    {
        "enrollment": "rit2011020",
        "name": "Samantha",
        "subject": [
            {
                "code": "COM",
                "grade": "B"
            },
            {
                "code": "DSA",
                "grade": "A"
            }
        ]
    }
   ]
}
'''

data = json.loads(report_string)

for student in data['report']:
    for grade in student['subject']:
        if grade['grade'] != 'F':
            print( grade['code'] + ' ' + grade['grade'] + " " + student['enrollment'] + " " + student['name'])

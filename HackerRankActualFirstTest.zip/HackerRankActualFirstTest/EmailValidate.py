def is_valid(address):
    #condition1 divided into two parts separated by @
    if ('@' in address):
        username = address[:address.index('@')]
        #condition2 part1 composed only of alphanumeric characters and has to start with an alphabet
        if username.isalnum() and username[:1].isalpha():
            address = address[address.index('@')+1:]
            #condition3 part2 divided into 2 or 3 segments separated by '.' character
            if address.count('.') <= 2:
                domain = address[:address.index('.')]
                extension = address[address.index('.')+1:]
                #check if 2 or 3 segments for conditions45
                if extension.count('.') == 1:
                    ext1 = extension[:extension.index('.')]
                    ext2 = extension[extension.index('.')+1:]
                    #condition5 very last segment is either 2 or 3 characters long and only contains alphabets
                    if ext1.isalnum() and ext2.isalpha() and len(ext2) < 4 and len(ext2) > 1:
                        return 'Valid'
                    else:
                        return 'Invalid'
                else:
                    ext1 = extension
                    #condition5 very last segment is either 2 or 3 characters long and only contains alphabets
                    if domain.isalnum() and ext1.isalpha() and len(ext1) < 4 and len(ext1) > 1:
                        return 'Valid'
                    else:
                        return 'Invalid'
                if domain.isalnum():
                    return 'Valid' + ext1
                else:
                    return 'Invalid'
            else:
                return 'Invalid'
        else:
            return 'Invalid'
    else:
        return 'Invalid' + username

if __name__ == '__main__':
    address = 'john.doe@springboard.com'
    print(is_valid(address))
